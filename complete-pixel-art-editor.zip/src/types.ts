export type RGBA = [number, number, number, number]; // r, g, b, a (0-255)

export interface Layer {
  id: string;
  name: string;
  visible: boolean;
  opacity: number; // 0-1
  pixels: (string | null)[][]; // null = transparent, string = hex color
}

export interface Frame {
  id: string;
  layers: Layer[];
}

export type Tool = 'pen' | 'eraser' | 'fill' | 'line' | 'rect' | 'circle' | 'eyedropper' | 'move' | 'select';

export interface EditorState {
  width: number;
  height: number;
  frames: Frame[];
  currentFrameIndex: number;
  currentLayerIndex: number;
  currentColor: string;
  currentTool: Tool;
  brushSize: number;
  zoom: number;
  panX: number;
  panY: number;
  showGrid: boolean;
  onionSkin: boolean;
}

export interface HistoryEntry {
  frames: Frame[];
  currentFrameIndex: number;
  currentLayerIndex: number;
}
